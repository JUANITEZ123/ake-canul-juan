SET search_path TO uni;

-- Trigger: al insertar préstamo ACTIVO, marcar ejemplar como 'prestado'
CREATE OR REPLACE FUNCTION trg_prestamo_set_estado_ejemplar()
RETURNS trigger AS $$
BEGIN
  IF NEW.estado = 'activo' THEN
    UPDATE ejemplar
      SET estado = 'prestado'
      WHERE id_ejemplar = NEW.id_ejemplar
        AND estado = 'disponible';
    IF NOT FOUND THEN
      RAISE EXCEPTION 'El ejemplar % no está disponible', NEW.id_ejemplar;
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER tg_prestamo_after_insert
AFTER INSERT ON prestamo
FOR EACH ROW EXECUTE FUNCTION trg_prestamo_set_estado_ejemplar();

-- Trigger: impedir > 3 préstamos activos por usuario
CREATE OR REPLACE FUNCTION trg_limitar_prestamos_activos()
RETURNS trigger AS $$
DECLARE activos INT;
BEGIN
  IF NEW.estado = 'activo' THEN
    SELECT COUNT(*) INTO activos
    FROM prestamo
    WHERE id_usuario = NEW.id_usuario AND estado = 'activo';
    IF activos >= 3 THEN
      RAISE EXCEPTION 'El usuario % ya tiene % préstamos activos', NEW.id_usuario, activos;
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER tg_prestamo_limit
BEFORE INSERT ON prestamo
FOR EACH ROW EXECUTE FUNCTION trg_limitar_prestamos_activos();

-- Vista: prestamos_activos
CREATE OR REPLACE VIEW prestamos_activos AS
SELECT
  p.id_prestamo,
  u.nombre || ' ' || u.apellido AS usuario,
  l.titulo AS libro,
  p.fecha_prestamo
FROM prestamo p
JOIN usuario u  ON u.id_usuario = p.id_usuario
JOIN ejemplar e ON e.id_ejemplar = p.id_ejemplar
JOIN libro l    ON l.id_libro = e.id_libro
WHERE p.estado = 'activo';

-- Procedimiento: registrar_prestamo(u, e)
CREATE OR REPLACE PROCEDURE registrar_prestamo(p_id_usuario INT, p_id_ejemplar INT)
LANGUAGE plpgsql
AS $$
DECLARE activos INT; est VARCHAR(20);
BEGIN
  SELECT COUNT(*) INTO activos
  FROM prestamo WHERE id_usuario = p_id_usuario AND estado = 'activo';
  IF activos >= 3 THEN
    RAISE EXCEPTION 'El usuario % ya tiene % préstamos activos', p_id_usuario, activos;
  END IF;

  SELECT estado INTO est FROM ejemplar WHERE id_ejemplar = p_id_ejemplar;
  IF est IS NULL THEN
    RAISE EXCEPTION 'Ejemplar % no existe', p_id_ejemplar;
  ELSIF est <> 'disponible' THEN
    RAISE EXCEPTION 'Ejemplar % no está disponible (estado=%)', p_id_ejemplar, est;
  END IF;

  INSERT INTO prestamo (id_usuario, id_ejemplar, fecha_prestamo, estado)
  VALUES (p_id_usuario, p_id_ejemplar, CURRENT_DATE, 'activo');
END;
$$;
