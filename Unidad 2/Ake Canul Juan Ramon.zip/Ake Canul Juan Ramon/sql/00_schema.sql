CREATE SCHEMA IF NOT EXISTS uni;
SET search_path TO uni;

CREATE TABLE usuario (
  id_usuario  SERIAL PRIMARY KEY,
  nombre      VARCHAR(80) NOT NULL,
  apellido    VARCHAR(80) NOT NULL,
  correo      VARCHAR(120) NOT NULL UNIQUE,
  tipo        VARCHAR(20)  NOT NULL CHECK (tipo IN ('estudiante','profesor'))
);

CREATE TABLE credencial (
  id_credencial SERIAL PRIMARY KEY,
  id_usuario    INT NOT NULL UNIQUE REFERENCES usuario(id_usuario) ON DELETE CASCADE,
  codigo        VARCHAR(40) NOT NULL UNIQUE,
  estado        VARCHAR(20) NOT NULL CHECK (estado IN ('activa','bloqueada'))
);

CREATE TABLE libro (
  id_libro         SERIAL PRIMARY KEY,
  titulo           VARCHAR(160) NOT NULL,
  autor            VARCHAR(120) NOT NULL,
  anio_publicacion INT NOT NULL,
  CONSTRAINT chk_libro_anio CHECK (anio_publicacion > 1500)
);

CREATE TABLE categoria (
  id_categoria SERIAL PRIMARY KEY,
  nombre       VARCHAR(60) NOT NULL UNIQUE
);

CREATE TABLE libro_categoria (
  id_libro     INT NOT NULL REFERENCES libro(id_libro) ON DELETE CASCADE,
  id_categoria INT NOT NULL REFERENCES categoria(id_categoria) ON DELETE CASCADE,
  PRIMARY KEY (id_libro, id_categoria)
);

CREATE TABLE ejemplar (
  id_ejemplar SERIAL PRIMARY KEY,
  id_libro    INT NOT NULL REFERENCES libro(id_libro),
  estado      VARCHAR(20) NOT NULL CHECK (estado IN ('disponible','prestado','danado'))
);

CREATE TABLE prestamo (
  id_prestamo       SERIAL PRIMARY KEY,
  id_usuario        INT NOT NULL REFERENCES usuario(id_usuario),
  id_ejemplar       INT NOT NULL REFERENCES ejemplar(id_ejemplar),
  fecha_prestamo    DATE NOT NULL DEFAULT CURRENT_DATE,
  fecha_devolucion  DATE,
  estado            VARCHAR(20) NOT NULL CHECK (estado IN ('activo','devuelto','vencido')),
  CONSTRAINT chk_fechas_prestamo
    CHECK (fecha_devolucion IS NULL OR fecha_devolucion >= fecha_prestamo)
);

-- Índices útiles (para las consultas pedidas)
CREATE INDEX idx_prestamo_usuario_estado  ON prestamo(id_usuario, estado);
CREATE INDEX idx_prestamo_ejemplar_estado ON prestamo(id_ejemplar, estado);
CREATE INDEX idx_ejemplar_libro           ON ejemplar(id_libro);
