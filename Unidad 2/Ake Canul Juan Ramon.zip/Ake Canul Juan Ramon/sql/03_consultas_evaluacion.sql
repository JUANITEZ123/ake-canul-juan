SET search_path TO uni;

-- 6) Usuarios que nunca han hecho un préstamo
SELECT u.*
FROM usuario u
LEFT JOIN prestamo p ON p.id_usuario = u.id_usuario
WHERE p.id_prestamo IS NULL;

-- 7) Libros más prestados en los últimos 6 meses
SELECT l.titulo, COUNT(*) AS veces
FROM prestamo p
JOIN ejemplar e ON e.id_ejemplar = p.id_ejemplar
JOIN libro l ON l.id_libro = e.id_libro
WHERE p.fecha_prestamo >= CURRENT_DATE - INTERVAL '6 months'
GROUP BY l.id_libro, l.titulo
ORDER BY veces DESC;

-- 8) Usuarios con préstamos vencidos (fecha_devolucion < hoy y no devuelto)
SELECT DISTINCT u.id_usuario, u.nombre, u.apellido, p.id_prestamo, p.fecha_devolucion
FROM prestamo p
JOIN usuario u ON u.id_usuario = p.id_usuario
WHERE p.fecha_devolucion < CURRENT_DATE
  AND p.estado <> 'devuelto';

-- 9) Libros y total de ejemplares disponibles por categoría
SELECT c.nombre AS categoria, l.titulo,
       SUM(CASE WHEN e.estado = 'disponible' THEN 1 ELSE 0 END) AS ejemplares_disponibles
FROM libro l
JOIN libro_categoria lc ON lc.id_libro = l.id_libro
JOIN categoria c ON c.id_categoria = lc.id_categoria
LEFT JOIN ejemplar e ON e.id_libro = l.id_libro
GROUP BY c.nombre, l.titulo
ORDER BY c.nombre, l.titulo;
