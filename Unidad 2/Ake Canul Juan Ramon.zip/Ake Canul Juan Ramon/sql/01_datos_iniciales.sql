SET search_path TO uni;

-- 3 estudiantes + 2 profesores
INSERT INTO usuario (nombre, apellido, correo, tipo) VALUES
('Ana','López','ana@uni.mx','estudiante'),
('Bruno','Pérez','bruno@uni.mx','estudiante'),
('Carla','Díaz','carla@uni.mx','estudiante'),
('David','Ruiz','david@uni.mx','profesor'),
('Elena','Mora','elena@uni.mx','profesor');

-- Credenciales 1:1
INSERT INTO credencial (id_usuario, codigo, estado) VALUES
(1,'CRED-ANA-001','activa'),
(2,'CRED-BRU-001','activa'),
(3,'CRED-CAR-001','activa'),
(4,'CRED-DAV-001','activa'),
(5,'CRED-ELE-001','activa');

-- Categorías
INSERT INTO categoria (nombre) VALUES
('Ciencia'),('Historia'),('Programación'),('Psicología'),('Novela');

-- Libros
INSERT INTO libro (titulo, autor, anio_publicacion) VALUES
('Introducción a PostgreSQL','R. Stone',2019),
('Aprende SQL Bien','M. Ortiz',2021),
('Neurociencia Básica','S. King',2018),
('Historia de México','L. Juárez',2010),
('Novela Corta','P. Lara',2007);

-- Múltiples categorías
INSERT INTO libro_categoria VALUES
(1,3),(1,1),
(2,3),
(3,1),(3,4),
(4,2),
(5,5);

-- 10 ejemplares con estados variados
INSERT INTO ejemplar (id_libro, estado) VALUES
(1,'disponible'),(1,'disponible'),
(2,'disponible'),(2,'prestado'),
(3,'disponible'),(3,'danado'),
(4,'disponible'),(4,'disponible'),
(5,'disponible'),(5,'prestado');

-- 5 préstamos (activos/devueltos/vencidos)
INSERT INTO prestamo (id_usuario, id_ejemplar, fecha_prestamo, fecha_devolucion, estado) VALUES
(1,2,  CURRENT_DATE - INTERVAL '10 days', CURRENT_DATE - INTERVAL '3 days',  'devuelto'),
(2,4,  CURRENT_DATE - INTERVAL '15 days', CURRENT_DATE - INTERVAL '5 days',  'activo'),
(3,10, CURRENT_DATE - INTERVAL '20 days', CURRENT_DATE - INTERVAL '7 days',  'vencido'),
(4,7,  CURRENT_DATE - INTERVAL '5 days',  CURRENT_DATE + INTERVAL '10 days', 'activo'),
(5,9,  CURRENT_DATE - INTERVAL '40 days', CURRENT_DATE - INTERVAL '2 days',  'devuelto');
