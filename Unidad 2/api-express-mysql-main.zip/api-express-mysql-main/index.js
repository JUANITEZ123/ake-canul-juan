// index.js
require("dotenv/config");
const express = require("express");
const cors = require("cors");
const { pool, ping } = require("./connection");

const app = express();
app.use(cors());
app.use(express.json());

// ------------------------ Healthcheck ------------------------
app.get("/health", async (_req, res) => {
  try {
    const now = await ping();
    res.json({ ok: true, dbTime: now });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

// ============================================================
// ===============           PRODUCTS           ===============
// ============================================================
app.get("/api/products", async (_req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM products ORDER BY id");
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: "Error al obtener productos" });
  }
});

app.get("/api/products/:id", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM products WHERE id = ?", [
      req.params.id,
    ]);
    if (!rows.length) return res.status(404).json({ message: "Not found" });
    res.json(rows[0]);
  } catch (e) {
    res.status(500).json({ error: "Error al obtener producto" });
  }
});

app.post("/api/products", async (req, res) => {
  try {
    const { name, description, price, stock, image } = req.body;
    if (!name || price == null || stock == null) {
      return res
        .status(400)
        .json({ message: "name, price, stock son requeridos" });
    }
    const [result] = await pool.query(
      `INSERT INTO products (name, description, price, stock, image, created_at)
       VALUES (?, ?, ?, ?, ?, NOW())`,
      [name, description ?? null, price, stock, image ?? null]
    );
    const [rows] = await pool.query("SELECT * FROM products WHERE id = ?", [
      result.insertId,
    ]);
    res.status(201).json(rows[0]);
  } catch (e) {
    res.status(500).json({ error: "Error al crear producto" });
  }
});

app.put("/api/products/:id", async (req, res) => {
  try {
    const { name, description, price, stock, image } = req.body;
    const [result] = await pool.query(
      `UPDATE products
         SET name = COALESCE(?, name),
             description = COALESCE(?, description),
             price = COALESCE(?, price),
             stock = COALESCE(?, stock),
             image = COALESCE(?, image)
       WHERE id = ?`,
      [name, description, price, stock, image, req.params.id]
    );
    if (result.affectedRows === 0)
      return res.status(404).json({ message: "Not found" });
    const [rows] = await pool.query("SELECT * FROM products WHERE id = ?", [
      req.params.id,
    ]);
    res.json(rows[0]);
  } catch (e) {
    res.status(500).json({ error: "Error al actualizar producto" });
  }
});

app.delete("/api/products/:id", async (req, res) => {
  try {
    const [result] = await pool.query("DELETE FROM products WHERE id = ?", [
      req.params.id,
    ]);
    if (result.affectedRows === 0)
      return res.status(404).json({ message: "Not found" });
    res.status(204).send();
  } catch (e) {
    res.status(500).json({ error: "Error al borrar producto" });
  }
});

// ============================================================
// ===============          PURCHASES           ===============
// ============================================================

// ---------- helpers ----------
function requireDetailsArray(details) {
  if (!Array.isArray(details) || details.length === 0) {
    return "Debe incluir al menos un producto en la compra";
  }
  if (details.length > 5) {
    return "No se pueden guardar más de 5 productos por compra";
  }
  for (const d of details) {
    if (
      !d ||
      d.product_id == null ||
      d.quantity == null ||
      d.price == null ||
      d.quantity <= 0 ||
      d.price < 0
    ) {
      return "Cada detalle requiere product_id, quantity (>0) y price (>=0)";
    }
  }
  return null;
}

// ---------- POST /api/purchases ----------
app.post("/api/purchases", async (req, res) => {
  const conn = await pool.getConnection();
  try {
    const { user_id, status, details } = req.body;

    if (!user_id || !status) {
      return res
        .status(400)
        .json({ message: "user_id y status son requeridos" });
    }

    const err = requireDetailsArray(details);
    if (err) return res.status(400).json({ message: err });

    await conn.beginTransaction();

    // Calcular total + validar stock
    let total = 0;
    for (const { product_id, quantity, price } of details) {
      const [[prod]] = await conn.query(
        "SELECT stock FROM products WHERE id = ? FOR UPDATE",
        [product_id]
      );
      if (!prod) {
        await conn.rollback();
        return res
          .status(404)
          .json({ message: `Producto ${product_id} no existe` });
      }
      if (prod.stock < quantity) {
        await conn.rollback();
        return res.status(409).json({
          message: `Stock insuficiente para product_id ${product_id}`,
        });
      }
      total += Number(price) * Number(quantity);
    }

    if (total > 3500) {
      await conn.rollback();
      return res
        .status(400)
        .json({ message: "El total no puede exceder $3500" });
    }

    // Insert purchase
    const [pResult] = await conn.query(
      `INSERT INTO purchases (user_id, total, status, purchase_date)
       VALUES (?, ?, ?, NOW())`,
      [user_id, total, status]
    );
    const purchaseId = pResult.insertId;

    // Insert details y descontar stock
    for (const { product_id, quantity, price } of details) {
      const subtotal = Number(price) * Number(quantity);
      await conn.query(
        `INSERT INTO purchase_details (purchase_id, product_id, quantity, price, subtotal)
         VALUES (?, ?, ?, ?, ?)`,
        [purchaseId, product_id, quantity, price, subtotal]
      );
      await conn.query(`UPDATE products SET stock = stock - ? WHERE id = ?`, [
        quantity,
        product_id,
      ]);
    }

    await conn.commit();

    // Respuesta con JOINs
    const [rows] = await conn.query(
      `SELECT p.id, u.name AS user, p.total, p.status, p.purchase_date,
              d.id AS detail_id, d.product_id, pr.name AS product, d.quantity, d.price, d.subtotal
         FROM purchases p
    LEFT JOIN users u ON u.id = p.user_id
    LEFT JOIN purchase_details d ON d.purchase_id = p.id
    LEFT JOIN products pr ON pr.id = d.product_id
        WHERE p.id = ?
     ORDER BY d.id`,
      [purchaseId]
    );

    const out = {
      id: rows[0].id,
      user: rows[0].user ?? null,
      total: Number(rows[0].total),
      status: rows[0].status,
      purchase_date: rows[0].purchase_date,
      details: rows
        .filter((r) => r.detail_id != null)
        .map((r) => ({
          id: r.detail_id,
          product: r.product ?? null,
          product_id: r.product_id,
          quantity: r.quantity,
          price: Number(r.price),
          subtotal: Number(r.subtotal),
        })),
    };

    res.status(201).json(out);
  } catch (e) {
    try {
      await conn.rollback();
    } catch {}
    res.status(500).json({ message: "Error inesperado", error: String(e) });
  } finally {
    conn.release();
  }
});

// ---------- PUT /api/purchases/:id ----------
app.put("/api/purchases/:id", async (req, res) => {
  const conn = await pool.getConnection();
  try {
    const id = Number(req.params.id);
    const { status, details } = req.body;

    const [[purchase]] = await conn.query(
      "SELECT * FROM purchases WHERE id = ? FOR UPDATE",
      [id]
    );
    if (!purchase) return res.status(404).json({ message: "Not found" });
    if (purchase.status === "COMPLETED")
      return res
        .status(409)
        .json({ message: "Una compra COMPLETED no puede modificarse" });

    const err = requireDetailsArray(details);
    if (err) return res.status(400).json({ message: err });

    await conn.beginTransaction();

    // Restaurar stock de los detalles previos
    const [prev] = await conn.query(
      "SELECT product_id, quantity FROM purchase_details WHERE purchase_id = ?",
      [id]
    );
    for (const { product_id, quantity } of prev) {
      await conn.query("UPDATE products SET stock = stock + ? WHERE id = ?", [
        quantity,
        product_id,
      ]);
    }
    await conn.query("DELETE FROM purchase_details WHERE purchase_id = ?", [
      id,
    ]);

    // Validar stock para nuevos detalles y calcular total
    let newTotal = 0;
    for (const { product_id, quantity, price } of details) {
      const [[prod]] = await conn.query(
        "SELECT stock FROM products WHERE id = ? FOR UPDATE",
        [product_id]
      );
      if (!prod) {
        await conn.rollback();
        return res
          .status(404)
          .json({ message: `Producto ${product_id} no existe` });
      }
      if (prod.stock < quantity) {
        await conn.rollback();
        return res.status(409).json({
          message: `Stock insuficiente para product_id ${product_id}`,
        });
      }
      newTotal += Number(price) * Number(quantity);
    }
    if (newTotal > 3500) {
      await conn.rollback();
      return res
        .status(400)
        .json({ message: "El total no puede exceder $3500" });
    }

    // Insertar nuevos detalles + descontar stock
    for (const { product_id, quantity, price } of details) {
      const subtotal = Number(price) * Number(quantity);
      await conn.query(
        `INSERT INTO purchase_details (purchase_id, product_id, quantity, price, subtotal)
         VALUES (?, ?, ?, ?, ?)`,
        [id, product_id, quantity, price, subtotal]
      );
      await conn.query("UPDATE products SET stock = stock - ? WHERE id = ?", [
        quantity,
        product_id,
      ]);
    }

    // Actualizar cabecera
    await conn.query(
      `UPDATE purchases
          SET total = ?, status = ?, purchase_date = NOW()
        WHERE id = ?`,
      [newTotal, status ?? purchase.status, id]
    );

    await conn.commit();

    // Respuesta con JOINs
    const [rows] = await conn.query(
      `SELECT p.id, u.name AS user, p.total, p.status, p.purchase_date,
              d.id AS detail_id, d.product_id, pr.name AS product, d.quantity, d.price, d.subtotal
         FROM purchases p
    LEFT JOIN users u ON u.id = p.user_id
    LEFT JOIN purchase_details d ON d.purchase_id = p.id
    LEFT JOIN products pr ON pr.id = d.product_id
        WHERE p.id = ?
     ORDER BY d.id`,
      [id]
    );

    const out = {
      id: rows[0]?.id ?? id,
      user: rows[0]?.user ?? null,
      total: rows[0] ? Number(rows[0].total) : newTotal,
      status: rows[0]?.status ?? status ?? purchase.status,
      purchase_date: rows[0]?.purchase_date ?? null,
      details: rows
        .filter((r) => r.detail_id != null)
        .map((r) => ({
          id: r.detail_id,
          product: r.product ?? null,
          product_id: r.product_id,
          quantity: r.quantity,
          price: Number(r.price),
          subtotal: Number(r.subtotal),
        })),
    };

    res.json(out);
  } catch (e) {
    try {
      await conn.rollback();
    } catch {}
    res.status(500).json({ message: "Error inesperado", error: String(e) });
  } finally {
    conn.release();
  }
});

// ---------- GET /api/purchases (lista con detalles) ----------
app.get("/api/purchases", async (_req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT p.id, u.name AS user, p.total, p.status, p.purchase_date,
              d.id AS detail_id, d.product_id, pr.name AS product, d.quantity, d.price, d.subtotal
         FROM purchases p
    LEFT JOIN users u ON u.id = p.user_id
    LEFT JOIN purchase_details d ON d.purchase_id = p.id
    LEFT JOIN products pr ON pr.id = d.product_id
     ORDER BY p.id, d.id`
    );

    const map = new Map();
    for (const r of rows) {
      if (!map.has(r.id)) {
        map.set(r.id, {
          id: r.id,
          user: r.user ?? null,
          total: Number(r.total),
          status: r.status,
          purchase_date: r.purchase_date,
          details: [],
        });
      }
      if (r.detail_id != null) {
        map.get(r.id).details.push({
          id: r.detail_id,
          product: r.product ?? null,
          product_id: r.product_id,
          quantity: r.quantity,
          price: Number(r.price),
          subtotal: Number(r.subtotal),
        });
      }
    }

    res.json(Array.from(map.values()));
  } catch (e) {
    res
      .status(500)
      .json({ message: "Error al listar compras", error: String(e) });
  }
});

// ---------- GET /api/purchases/:id (una compra con detalles) ----------
app.get("/api/purchases/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [rows] = await pool.query(
      `SELECT p.id, u.name AS user, p.total, p.status, p.purchase_date,
              d.id AS detail_id, d.product_id, pr.name AS product, d.quantity, d.price, d.subtotal
         FROM purchases p
    LEFT JOIN users u ON u.id = p.user_id
    LEFT JOIN purchase_details d ON d.purchase_id = p.id
    LEFT JOIN products pr ON pr.id = d.product_id
        WHERE p.id = ?
     ORDER BY d.id`,
      [id]
    );

    if (!rows.length) return res.status(404).json({ message: "Not found" });

    const out = {
      id: rows[0].id,
      user: rows[0].user ?? null,
      total: Number(rows[0].total),
      status: rows[0].status,
      purchase_date: rows[0].purchase_date,
      details: rows
        .filter((r) => r.detail_id != null)
        .map((r) => ({
          id: r.detail_id,
          product: r.product ?? null,
          product_id: r.product_id,
          quantity: r.quantity,
          price: Number(r.price),
          subtotal: Number(r.subtotal),
        })),
    };

    res.json(out);
  } catch (e) {
    res
      .status(500)
      .json({ message: "Error al obtener compra", error: String(e) });
  }
});

// ---------- DELETE /api/purchases/:id ----------
app.delete("/api/purchases/:id", async (req, res) => {
  const conn = await pool.getConnection();
  try {
    const id = Number(req.params.id);

    await conn.beginTransaction();

    const [[p]] = await conn.query(
      "SELECT id, status FROM purchases WHERE id = ? FOR UPDATE",
      [id]
    );
    if (!p) {
      await conn.rollback();
      return res.status(404).json({ message: "Not found" });
    }
    if (p.status === "COMPLETED") {
      await conn.rollback();
      return res
        .status(409)
        .json({ message: "No se pueden borrar compras en estatus COMPLETED" });
    }

    // Restaurar stock por cada detalle
    const [details] = await conn.query(
      "SELECT product_id, quantity FROM purchase_details WHERE purchase_id = ?",
      [id]
    );
    for (const { product_id, quantity } of details) {
      await conn.query("UPDATE products SET stock = stock + ? WHERE id = ?", [
        quantity,
        product_id,
      ]);
    }

    await conn.query("DELETE FROM purchase_details WHERE purchase_id = ?", [
      id,
    ]);
    await conn.query("DELETE FROM purchases WHERE id = ?", [id]);

    await conn.commit();
    res
      .status(200)
      .json({ message: "Compra eliminada", id: Number(req.params.id) });
  } catch (e) {
    try {
      await conn.rollback();
    } catch {}
    res
      .status(500)
      .json({ message: "Error al borrar compra", error: String(e) });
  } finally {
    conn.release();
  }
});

// ------------------------ Start ------------------------
const PORT = Number(process.env.PORT || 3000);
app.listen(PORT, () =>
  console.log(`API listening on http://localhost:${PORT}`)
);
